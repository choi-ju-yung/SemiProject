package com.semi.productpage.model.vo;

public class ajaxUpdateHeart {

}
