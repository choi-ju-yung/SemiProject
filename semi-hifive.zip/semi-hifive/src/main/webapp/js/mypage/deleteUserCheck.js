const clearInput = () => {
	$("#password").val("").focus();
}